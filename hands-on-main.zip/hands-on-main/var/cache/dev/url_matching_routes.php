<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/open-bank-account' => [[['_route' => 'open_bank_account', '_controller' => 'App\\Api\\Action\\OpenBankAccountAction'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/close\\-bank\\-account/([^/]++)(*:72)'
                .'|/get\\-bank\\-account/([^/]++)(*:107)'
                .'|/set\\-overdraft\\-limit/([^/]++)(*:146)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        72 => [[['_route' => 'close-bank-account', '_controller' => 'App\\Api\\Action\\CloseBankAccountAction'], ['bankAccountId'], ['POST' => 0], null, false, true, null]],
        107 => [[['_route' => 'get-bank-account', '_controller' => 'App\\Api\\Action\\GetBankAccountAction'], ['bankAccountId'], ['GET' => 0], null, false, true, null]],
        146 => [
            [['_route' => 'set_overdraft_limit', '_controller' => 'App\\Api\\Action\\SetOverdraftLimitAction'], ['bankAccountId'], ['POST' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
