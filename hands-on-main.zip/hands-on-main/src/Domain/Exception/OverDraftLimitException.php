<?php

namespace App\Domain\Exception;

use RuntimeException;

class OverDraftLimitException extends RuntimeException {}
