<?php

namespace App\Domain\Exception;

use InvalidArgumentException;

class InvalidDepositAmountException extends InvalidArgumentException {}
