<?php

namespace App\Domain\Exception;

use InvalidArgumentException;

class InvalidWithDrawnAmountException extends InvalidArgumentException {}
